#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 10:23:02 2019

@author: bleyerj
"""
from dolfinx.fem import (
    Function,
    functionspace,
    Constant,
    Expression,
    locate_dofs_topological,
    locate_dofs_geometrical,
    dirichletbc,
    assemble_scalar,
    form,
)
from dolfinx.fem.petsc import LinearProblem
from dolfinx.io import XDMFFile
from ufl import (
    max_value,
    min_value,
    Measure,
    grad,
    sym,
    inner,
    tr,
    Identity,
    TrialFunction,
    TestFunction,
    dx,
)
import warnings
import logging
import numpy as np
from mpi4py import MPI
from petsc4py.PETSc import ScalarType
from plotting import plot_damage, create_grid

logging.disable(logging.INFO)
linear_solver = "lu"  # or "mumps"


def solve_problem(mesh, facets, prob_params, mech_params, plot_every=0):

    problem, unloading, export_results, Nitermax, tol = prob_params
    E, nu, R0, alpha, Umax, Nincr = mech_params

    ds = Measure("ds", domain=mesh, subdomain_data=facets)

    lmbda = Constant(mesh, E * nu / (1 + nu) / (1 - 2 * nu))
    mu = Constant(mesh, E / 2 / (1 + nu))
    lmbda_ps = (
        2 * mu * lmbda / (lmbda + 2 * mu)
    )  # effective lambda modulus for plane stress

    def eps(v):
        return sym(grad(v))

    def sigma0(v):
        return lmbda_ps * tr(eps(v)) * Identity(2) + 2 * mu * eps(v)

    def sigma(v, d):
        return (1 - d) * sigma0(v)

    def compute_damage(u):
        Y = 0.5 * inner(sigma0(u), eps(u))
        return min_value(
            (Y / Constant(mesh, ScalarType(R0)) - 1)
            / Constant(mesh, ScalarType(alpha)),
            1.0 - 1e-8,
        )

    if unloading:
        load_steps = np.concatenate(
            (
                np.linspace(0, 3 * Umax / 4, Nincr // 2 + 1),
                np.linspace(3 * Umax / 4, 0, 10)[1:],
                np.linspace(0, Umax, Nincr // 2 + 1)[1:],
            )
        )
    else:
        load_steps = np.linspace(0, Umax, Nincr + 1)

    # function space for the displacement
    V_u = functionspace(mesh, ("CG", 1, (2,)))
    # function space for the damage
    V_d = functionspace(mesh, ("DG", 0))
    # # function space for the stress
    V_sig = functionspace(mesh, ("DG", 0, (2, 2)))

    Uimp = Constant(mesh, 0.0)

    def point(x):
        return np.logical_and(np.isclose(x[0], 0), np.isclose(x[1], 0))

    left_dofs = locate_dofs_topological(
        V_u.sub(0), facets.dim, facets.indices[facets.values == 1]
    )
    right_dofs = locate_dofs_topological(
        V_u.sub(0), facets.dim, facets.indices[facets.values == 2]
    )
    Uimp = Constant(mesh, 0.0)
    point_dof = locate_dofs_geometrical(V_u, point)
    bcs = [
        dirichletbc(0.0, left_dofs, V_u.sub(0)),
        dirichletbc(Uimp, right_dofs, V_u.sub(0)),
        dirichletbc(np.zeros((2,)), point_dof, V_u),
    ]

    d = Function(V_d, name="Damage")
    dold = Function(V_d, name="Previous_damage")
    dlb = Function(V_d, name="Lower_bound_d_n")
    u = Function(V_u, name="Total_displacement")
    v = TrialFunction(V_u)
    u_ = TestFunction(V_u)
    sig = Function(V_sig, name="Stress")

    # bilinear and l form for elasticity problem
    a = inner(eps(v), sigma(u_, dold)) * dx
    l = Constant(mesh, 0.0) * u_[0] * dx
    # linear elastic problem at fixed damage
    problem_u = LinearProblem(
        a,
        l,
        bcs=bcs,
        u=u,
        petsc_options={"ksp_type": "preonly", "pc_type": linear_solver},
    )

    Nincr = len(load_steps) - 1
    ffile = XDMFFile(MPI.COMM_WORLD, "results.xdmf", "w")
    ffile.write_mesh(mesh)

    # Pyvista plotting grid
    grid = create_grid(mesh)

    results = np.zeros((Nincr + 1, 3))
    t = 0
    for i, t in enumerate(load_steps[1:]):
        Uimp.value = t
        print("Increment {:3d}".format(i + 1))
        niter = 0
        for niter in range(Nitermax):
            # Solve displacement
            problem_u.solve()
            # Compute new damage
            d_expr = Expression(
                max_value(dlb, compute_damage(u)), V_d.element.interpolation_points()
            )
            d.interpolate(d_expr)
            # Compute difference between new and old damage
            nRes = max(d.x.array - dold.x.array)
            # Update damage
            d.x.petsc_vec.copy(dold.x.petsc_vec)

            print("    Iteration {:3d}: ||Res||={:5e}".format(niter, nRes))
            if nRes < tol:
                break
        else:
            warnings.warn("Too many iterations in fixed point algorithm")

        # compute apparent stress and max damage
        W = assemble_scalar(form(Constant(mesh, 1.0) * ds(2)))
        Sig_app = assemble_scalar(form(sigma(u, d)[0, 0] * ds(2))) / W
        d_max = max(d.x.petsc_vec.array)
        results[i + 1, :] = (t, Sig_app, d_max)

        # update lower bound for irreversibility
        d.x.petsc_vec.copy(dlb.x.petsc_vec)

        # compute stress
        stress_expr = Expression(sigma(u, d), V_sig.element.interpolation_points())
        sig.interpolate(stress_expr)

        # Create plotter
        if (plot_every > 0 and i % plot_every == 0) or (
            plot_every == 0 and i == Nincr - 1
        ):
            plot_damage(grid, d)

        # Export to Paraview
        if export_results:
            ffile.write_function(d, t)
            ffile.write_function(u, t)
            ffile.write_function(sig, t)

        ffile.close()

    return results, u, d, sig
