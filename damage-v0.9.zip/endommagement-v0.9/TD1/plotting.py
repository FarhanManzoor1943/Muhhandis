import matplotlib.pyplot as plt
import numpy as np
import pyvista
import dolfinx


pyvista.OFF_SCREEN = False
pyvista.set_jupyter_backend("static")
FIGSIZE = (600, 600)


def plot_results(problem, results, E, R0, alpha, d, u, sig, mesh, export_results=True):
    Ediss = np.trapz(results[:, 1], x=results[:, 0])
    print("Dissipated energy/R0:", Ediss / float(R0))
    sigmax = max(results[:, 1])
    epsmax = results[np.where(results[:, 1] == sigmax)[0][0], 0]
    print("Maximum stress:      ", sigmax)
    print("Strain at max stress:", epsmax)

    plt.figure()
    plt.plot(results[:, 0], results[:, 1], "-x", label="FE solution")
    plt.plot([epsmax, epsmax, 0], [0, sigmax, sigmax], "--k", linewidth=1)
    exx = results[:, 0]
    s = E * exx
    exx0 = (2 * R0 / E) ** 0.5
    exxd = exx[exx >= exx0]
    dam = 0 * exx
    dam[exx >= exx0] = np.minimum(1.0, (0.5 * E * exxd**2 - R0) / alpha / R0)
    s[exx >= exx0] = np.maximum(0, (1 - dam[exx >= exx0]) * E * exxd)
    if problem == "homog":
        plt.plot(exx, s, "--", label="Homogeneous solution")
    plt.xlabel("Uniaxial strain $\epsilon_{xx}$")
    plt.ylabel("Apparent stress $F/S$ (MPa)")
    plt.legend()
    if export_results:
        plt.savefig("stress_strain_curve.pdf")
    plt.show()

    plt.figure()
    plt.plot(results[:, 0], results[:, 2], "-x", label="FE solution")
    if problem == "homog":
        plt.plot(exx, dam, "--", label="Homogeneous solution")
    plt.xlabel("Uniaxial strain $\epsilon_{xx}$")
    plt.ylabel("Maximum damage")
    plt.ylim(0, 1.2)
    plt.legend()
    if export_results:
        plt.savefig("damage_evol_curve.pdf")
    plt.show()


def create_grid(mesh):
    V = dolfinx.fem.functionspace(mesh, ("CG", 1))
    # Create pyvista grid
    topology, cell_types, geometry = dolfinx.plot.vtk_mesh(V)
    return pyvista.UnstructuredGrid(topology, cell_types, geometry)


def plot_mesh(mesh):
    # Create plotter
    plotter = pyvista.Plotter(window_size=FIGSIZE)
    # we first add the grid
    grid = create_grid(mesh)
    plotter.add_mesh(grid, show_edges=True, style="wireframe", color="k")
    # Then we display the scene
    plotter.view_xy()
    plotter.show()


def plot_damage(grid, d):
    plotter = pyvista.Plotter()
    grid.cell_data["d"] = d.x.array
    grid.set_active_scalars("d")
    plotter.add_mesh(
        grid, show_edges=False, show_scalar_bar=True, clim=[0, 1], cmap="bone_r"
    )
    plotter.add_mesh(grid, show_edges=True, opacity=0.25, style="wireframe", color="k")
    plotter.view_xy()
    plotter.show()
