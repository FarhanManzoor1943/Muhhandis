#!/usr/bin/env python
# coding: utf-8

# # Numerical aspects of local damage models

# In[ ]:


from generate_mesh import setup_geometry
from local_damage import solve_problem
from plotting import plot_mesh, plot_results

problem = "homog"
refinement_level = 0
hole_spacing = 0.0
hole_radius = 0.2
aspect_ratio = 1.0
unloading = False
export_results = True

## Material properties
#   - Elastic properties
E = 6e3
nu = 0.3
#   - Damage properties
R0 = 3e-3
alpha = 1
# Loading steps
Nincr = 100
# Maximum imposed displacement
Umax = 3e-3

mesh, facets = setup_geometry(
    problem, refinement_level, hole_spacing, hole_radius, aspect_ratio
)

plot_mesh(mesh)


# Maximum number of increments in fixed point
Nitermax = 200
# Convergence tolerance for fixed point
tol = 1e-4
mech_params = (E, nu, R0, alpha, Umax, Nincr)
prob_params = (problem, unloading, export_results, Nitermax, tol)


# In[ ]:


results, u, d, sig = solve_problem(mesh, facets, prob_params, mech_params)


# In[ ]:


plot_results(problem, results, E, R0, alpha, d, u, sig, mesh, export_results)
