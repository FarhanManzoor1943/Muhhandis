import dolfinx
from dolfinx.io.gmshio import model_to_mesh
from mpi4py import MPI
import numpy as np
import gmsh


def generate_perforated_plate(L, W, R, hole_spacing, aspect_ratio, refinement_level):
    gmsh.initialize()

    gdim = 2
    mesh_comm = MPI.COMM_WORLD
    model_rank = 0
    if mesh_comm.rank == model_rank:
        rectangle = gmsh.model.occ.addRectangle(0, 0, 0, L, W, tag=1)
        bot_hole = gmsh.model.occ.addDisk(
            L / 2 - hole_spacing,
            0,
            0,
            R,
            R / aspect_ratio,
            zAxis=[0, 0, 1],
            xAxis=[0.0, 1.0, 0.0],
        )
        top_hole = gmsh.model.occ.addDisk(
            L / 2 + hole_spacing,
            W,
            0,
            R,
            R / aspect_ratio,
            zAxis=[0, 0, 1],
            xAxis=[0.0, 1.0, 0.0],
        )
        gmsh.model.occ.cut([(gdim, rectangle)], [(gdim, bot_hole), (gdim, top_hole)])
        gmsh.model.occ.synchronize()

        volumes = gmsh.model.getEntities(gdim)
        assert len(volumes) == 1
        gmsh.model.addPhysicalGroup(gdim, [volumes[0][1]], 1)
        gmsh.model.setPhysicalName(gdim, 1, "Plate")

        a = ((1 + 1 / aspect_ratio) * R) / 2 + hole_spacing
        coarse_size = W / 10
        fine_size = coarse_size * 2 ** (-refinement_level)
        # Create a new scalar field
        field_tag = gmsh.model.mesh.field.add("Box")
        gmsh.model.mesh.field.setNumber(field_tag, "VIn", fine_size)
        gmsh.model.mesh.field.setNumber(field_tag, "VOut", coarse_size)
        gmsh.model.mesh.field.setNumber(field_tag, "XMin", L / 2 - a)
        gmsh.model.mesh.field.setNumber(field_tag, "XMax", L / 2 + a)
        gmsh.model.mesh.field.setNumber(field_tag, "YMin", 0)
        gmsh.model.mesh.field.setNumber(field_tag, "YMax", W)

        gmsh.model.mesh.field.setAsBackgroundMesh(field_tag)

        gmsh.model.mesh.generate(gdim)

        mesh, _, ft = model_to_mesh(gmsh.model, mesh_comm, model_rank, gdim=gdim)
        ft.name = "Facet markers"

        gmsh.finalize()
    return mesh, ft


def setup_geometry(
    problem="homog", refinement_level=0, hole_spacing=0, hole_radius=0.1, aspect_ratio=1
):
    L, W, R = 1.0, 0.5, hole_radius

    if problem != "perforated":
        L, W = 1.0, 1.0
        mesh = dolfinx.mesh.create_rectangle(
            MPI.COMM_WORLD,
            [np.array([0, 0]), np.array([L, W])],
            [2**refinement_level, 1],
        )
    else:
        mesh, facets = generate_perforated_plate(
            L, W, R, hole_spacing, aspect_ratio, refinement_level
        )

    # Define boundaries and boundary integration measure
    def left(x):
        return np.isclose(x[0], 0)

    def right(x):
        return np.isclose(x[0], L)

    fdim = mesh.topology.dim - 1
    facet_indices, facet_markers = [], []
    left_facets = dolfinx.mesh.locate_entities_boundary(mesh, fdim, left)
    facet_indices.append(left_facets)
    facet_markers.append(np.full_like(left_facets, 1))
    right_facets = dolfinx.mesh.locate_entities_boundary(mesh, fdim, right)
    facet_indices.append(right_facets)
    facet_markers.append(np.full_like(right_facets, 2))

    facet_indices = np.hstack(facet_indices).astype(np.int32)
    facet_markers = np.hstack(facet_markers).astype(np.int32)
    sorted_facets = np.argsort(facet_indices)
    facet_tag = dolfinx.mesh.meshtags(
        mesh, fdim, facet_indices[sorted_facets], facet_markers[sorted_facets]
    )
    return mesh, facet_tag
