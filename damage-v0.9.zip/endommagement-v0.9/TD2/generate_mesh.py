import dolfinx
from dolfinx.io.gmshio import model_to_mesh
from mpi4py import MPI
import numpy as np
import gmsh


def generate_perforated_plate(L, W, R, hole_spacing, aspect_ratio, refinement_level):
    gmsh.initialize()

    gdim = 2
    mesh_comm = MPI.COMM_WORLD
    model_rank = 0
    if mesh_comm.rank == model_rank:
        rectangle = gmsh.model.occ.addRectangle(0, 0, 0, L, W, tag=1)
        bot_hole = gmsh.model.occ.addDisk(
            L / 2 - hole_spacing,
            0,
            0,
            R,
            R / aspect_ratio,
            zAxis=[0, 0, 1],
            xAxis=[0.0, 1.0, 0.0],
        )
        top_hole = gmsh.model.occ.addDisk(
            L / 2 + hole_spacing,
            W,
            0,
            R,
            R / aspect_ratio,
            zAxis=[0, 0, 1],
            xAxis=[0.0, 1.0, 0.0],
        )
        gmsh.model.occ.cut([(gdim, rectangle)], [(gdim, bot_hole), (gdim, top_hole)])
        gmsh.model.occ.synchronize()

        volumes = gmsh.model.getEntities(gdim)
        assert len(volumes) == 1
        gmsh.model.addPhysicalGroup(gdim, [volumes[0][1]], 1)
        gmsh.model.setPhysicalName(gdim, 1, "Plate")

        a = ((1 + 1 / aspect_ratio) * R) / 2 + hole_spacing
        coarse_size = W / 20
        fine_size = coarse_size * 2 ** (-refinement_level)
        # Create a new scalar field
        field_tag = gmsh.model.mesh.field.add("Box")
        gmsh.model.mesh.field.setNumber(field_tag, "VIn", fine_size)
        gmsh.model.mesh.field.setNumber(field_tag, "VOut", coarse_size)
        gmsh.model.mesh.field.setNumber(field_tag, "XMin", L / 2 - a)
        gmsh.model.mesh.field.setNumber(field_tag, "XMax", L / 2 + a)
        gmsh.model.mesh.field.setNumber(field_tag, "YMin", 0)
        gmsh.model.mesh.field.setNumber(field_tag, "YMax", W)

        gmsh.model.mesh.field.setAsBackgroundMesh(field_tag)

        gmsh.model.mesh.generate(gdim)

        mesh, _, ft = model_to_mesh(gmsh.model, mesh_comm, model_rank, gdim=gdim)
        ft.name = "Facet markers"

        gmsh.finalize()
    return mesh, ft


def generate_homog(refinement_level):
    L = 1.0
    W = 0.1

    gmsh.initialize()
    gdim = 2
    mesh_comm = MPI.COMM_WORLD
    model_rank = 0
    if mesh_comm.rank == model_rank:
        gmsh.model.occ.addRectangle(0, 0, 0, L, W, tag=1)
        gmsh.model.occ.synchronize()

        volumes = gmsh.model.getEntities(gdim)
        assert len(volumes) == 1
        gmsh.model.addPhysicalGroup(gdim, [volumes[0][1]], 1)
        gmsh.model.setPhysicalName(gdim, 1, "Plate")

        size = 0.8 * L * 2 ** (- refinement_level)
        gmsh.option.setNumber("Mesh.CharacteristicLengthMin", size)
        gmsh.option.setNumber("Mesh.CharacteristicLengthMax", size)

        gmsh.model.mesh.generate(gdim)
        
        mesh, _, ft = model_to_mesh(gmsh.model, mesh_comm, model_rank, gdim=gdim)
        ft.name = "Facet markers"

        gmsh.finalize()
    return mesh, ft


def generate_shear(L, W, refinement_level):
    a = L / 2

    gmsh.initialize()
    gdim = 2
    mesh_comm = MPI.COMM_WORLD
    model_rank = 0
    if mesh_comm.rank == model_rank:
        rectangle = gmsh.model.occ.addRectangle(0, 0, 0, L, W, tag=1)
        crack = gmsh.model.occ.addDisk(
            0,
            L / 2,
            0,
            a,
            a / 100,
        )
        gmsh.model.occ.cut([(gdim, rectangle)], [(gdim, crack)])
        gmsh.model.occ.synchronize()

        volumes = gmsh.model.getEntities(gdim)
        assert len(volumes) == 1
        gmsh.model.addPhysicalGroup(gdim, [volumes[0][1]], 1)
        gmsh.model.setPhysicalName(gdim, 1, "Plate")

        coarse_size = L / 50
        fine_size = coarse_size * 2 ** (-refinement_level)
        # Create a new scalar field
        field_tag = gmsh.model.mesh.field.add("Box")
        gmsh.model.mesh.field.setNumber(field_tag, "VIn", fine_size)
        gmsh.model.mesh.field.setNumber(field_tag, "VOut", coarse_size)
        gmsh.model.mesh.field.setNumber(field_tag, "XMin", a)
        gmsh.model.mesh.field.setNumber(field_tag, "XMax", L)
        gmsh.model.mesh.field.setNumber(field_tag, "YMin", 0)
        gmsh.model.mesh.field.setNumber(field_tag, "YMax", W)

        gmsh.model.mesh.field.setAsBackgroundMesh(field_tag)
        
        gmsh.model.mesh.generate(gdim)
        
        mesh, _, ft = model_to_mesh(gmsh.model, mesh_comm, model_rank, gdim=gdim)
        ft.name = "Facet markers"

        gmsh.finalize()
    return mesh, ft


def setup_geometry(
    problem="homog", refinement_level=0, hole_spacing=0, hole_radius=0.1, aspect_ratio=1
):

    if problem == "homog":
        L, W = 1.0, 0.1
        if refinement_level == 0:
            mesh = dolfinx.mesh.create_rectangle(
                MPI.COMM_WORLD,
                [np.array([0, 0]), np.array([L, W])],
                [1, 1],
            )
        else:
            mesh, facets = generate_homog(refinement_level)
            
    elif problem == "perforated":
        L, W, R = 1.0, 0.5, hole_radius
        mesh, facets = generate_perforated_plate(
            L, W, R, hole_spacing, aspect_ratio, refinement_level
        )
    elif problem == "shear":
        L, W, = (
            1.0,
            1.0,
        )
        mesh, facets = generate_shear(L, W, refinement_level)
    else:
        raise ValueError(
            "Unsupport problem type. Supported \
                         problems are 'homog', 'perforated', or 'shear'."
        )

    # Define boundaries and boundary integration measure
    def left(x):
        return np.isclose(x[0], 0)

    def right(x):
        return np.isclose(x[0], L)

    def bottom(x):
        return np.isclose(x[1], 0)

    def top(x):
        return np.isclose(x[1], W)

    fdim = mesh.topology.dim - 1
    facet_indices, facet_markers = [], []

    boundaries = {1: left, 2: right, 3: bottom, 4: top}
    for marker, locator in boundaries.items():
        boundary_facets = dolfinx.mesh.locate_entities_boundary(mesh, fdim, locator)
        facet_indices.append(boundary_facets)
        facet_markers.append(np.full_like(boundary_facets, marker))

    facet_indices = np.hstack(facet_indices).astype(np.int32)
    facet_markers = np.hstack(facet_markers).astype(np.int32)
    sorted_facets = np.argsort(facet_indices)
    facet_tag = dolfinx.mesh.meshtags(
        mesh, fdim, facet_indices[sorted_facets], facet_markers[sorted_facets]
    )
    return mesh, facet_tag
