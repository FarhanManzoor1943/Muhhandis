#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 10:23:02 2019

@author: bleyerj
"""
import dolfinx
from dolfinx.fem import (
    Function,
    functionspace,
    Constant,
    Expression,
    locate_dofs_topological,
    locate_dofs_geometrical,
    dirichletbc,
    assemble_scalar,
    form,
    set_bc,
)
from dolfinx.fem.petsc import LinearProblem
from dolfinx.io import XDMFFile
from ufl import (
    derivative,
    dot,
    Measure,
    grad,
    sym,
    inner,
    tr,
    Identity,
    TrialFunction,
    TestFunction,
    dx,
)
import warnings
import numpy as np
from mpi4py import MPI
from petsc4py import PETSc
from plotting import plot_damage, create_grid
from tao_problem import TAOProblem
import logging

logging.disable(logging.INFO)

linear_solver = "lu"  # or "mumps"


def solve_problem(mesh, facets, prob_params, mech_params, PYVISTA_ON, plot_every=0):

    problem, bcs_damage, unloading, export_results, Nitermax, tol = prob_params
    E, nu, Gc, l0, model, Umax, Nincr = mech_params

    ds = Measure("ds", domain=mesh, subdomain_data=facets)

    lmbda = Constant(mesh, E * nu / (1 + nu) / (1 - 2 * nu))
    mu = Constant(mesh, E / 2 / (1 + nu))
    lmbda_ps = (
        2 * mu * lmbda / (lmbda + 2 * mu)
    )  # effective lambda modulus for plane stress
    kres = Constant(mesh, 1e-6)  # residual stiffness
    l0 = Constant(mesh, l0)
    Gc = Constant(mesh, Gc)

    def eps(v):
        return sym(grad(v))

    def sigma0(v):
        return lmbda_ps * tr(eps(v)) * Identity(2) + 2 * mu * eps(v)

    def sigma(v, d):
        return ((1 - d) ** 2 + kres) * sigma0(v)

    if unloading:
        load_steps = np.concatenate(
            (
                np.linspace(0, 3 * Umax / 4, Nincr // 2 + 1),
                np.linspace(3 * Umax / 4, 0, 20)[1:],
                np.linspace(0, Umax, Nincr // 2 + 1)[1:],
            )
        )
    else:
        load_steps = np.linspace(0, Umax, Nincr + 1)

    # function space for the displacement
    V_u = functionspace(mesh, ("CG", 1, (2,)))
    # function space for the damage
    V_d = functionspace(mesh, ("CG", 1))
    # function space for the stress
    V_sig = functionspace(mesh, ("DG", 0, (2, 2)))

    Uimp = Constant(mesh, 0.0)

    def point(x):
        return np.logical_and(np.isclose(x[0], 0), np.isclose(x[1], 0))

    Uimp = Constant(mesh, 0.0)
    point_dof = locate_dofs_geometrical(V_u, point)

    if problem in ["homog", "perforated"]:
        left_dofs = locate_dofs_topological(
            V_u.sub(0), facets.dim, facets.indices[facets.values == 1]
        )
        right_dofs = locate_dofs_topological(
            V_u.sub(0), facets.dim, facets.indices[facets.values == 2]
        )
        bcs = [
            dirichletbc(0.0, left_dofs, V_u.sub(0)),
            dirichletbc(Uimp, right_dofs, V_u.sub(0)),
            dirichletbc(np.zeros((2,)), point_dof, V_u),
        ]
    elif problem == "shear":
        bottom_dofs = locate_dofs_topological(
            V_u, facets.dim, facets.indices[facets.values == 3]
        )
        right_dofs_x = locate_dofs_topological(
            V_u.sub(0), facets.dim, facets.indices[facets.values == 4]
        )
        right_dofs_y = locate_dofs_topological(
            V_u.sub(1), facets.dim, facets.indices[facets.values == 4]
        )
        bcs = [
            dirichletbc(np.zeros((2,)), bottom_dofs, V_u),
            dirichletbc(Uimp, right_dofs_x, V_u.sub(0)),
            dirichletbc(0.0, right_dofs_y, V_u.sub(1)),
        ]

    u = Function(V_u, name="Total_displacement")
    v = TrialFunction(V_u)
    u_ = TestFunction(V_u)
    sig = Function(V_sig, name="Current_stress")

    d = Function(V_d, name="Damage")
    dold = Function(V_d, name="Previous_damage")
    dub = Function(V_d, name="Upper_bound_d=1")
    dub.x.array[:] = 1.0
    dlb = Function(V_d, name="Lower_bound_d_n")
    d_ = TestFunction(V_d)
    dd = TrialFunction(V_d)
    # boundary conditions for damage problem
    if bcs_damage:
        left_dofs = locate_dofs_topological(
            V_d, facets.dim, facets.indices[facets.values == 1]
        )
        right_dofs = locate_dofs_topological(
            V_d, facets.dim, facets.indices[facets.values == 2]
        )
        bc_d = [dirichletbc(0.0, left_dofs, V_d), dirichletbc(0.0, right_dofs, V_d)]
    else:
        bc_d = []

    set_bc(dub.x.petsc_vec, bc_d)

    # bilinear and l form for elasticity problem
    a = inner(eps(v), sigma(u_, dold)) * dx
    l = Constant(mesh, 0.0) * u_[0] * dx
    # linear elastic problem at fixed damage
    problem_u = LinearProblem(
        a,
        l,
        bcs=bcs,
        u=u,
        petsc_options={"ksp_type": "preonly", "pc_type": linear_solver},
    )

    # total energy for the damage problem
    psi = 0.5 * inner(sigma(u, d), eps(u))
    elastic_energy = psi * dx
    if model == "AT1":
        cw = Constant(mesh, 8 / 3.0)
        w = lambda d: d
    elif model == "AT2":
        cw = Constant(mesh, 2.0)
        w = lambda d: d**2
    fracture_energy = Gc / cw * (w(d) / l0 + l0 * dot(grad(d), grad(d))) * dx
    total_energy = elastic_energy + fracture_energy
    # first derivative of energy with respect to d
    F_dam = derivative(total_energy, d, d_)
    # second derivative of energy with respect to d
    J_dam = derivative(F_dam, d, dd)
    # Definition of the optimisation problem with respect to d
    damage_problem = TAOProblem(total_energy, F_dam, J_dam, d, bc_d)

    b = dolfinx.la.create_petsc_vector(V_d.dofmap.index_map, V_d.dofmap.index_map_bs)
    J = dolfinx.fem.petsc.create_matrix(damage_problem.a)

    # Create PETSc TAO
    solver_d_tao = PETSc.TAO().create()
    solver_d_tao.setType("tron")
    solver_d_tao.setObjective(damage_problem.f)
    solver_d_tao.setGradient(damage_problem.F, b)
    solver_d_tao.setHessian(damage_problem.J, J)
    solver_d_tao.setTolerances(grtol=1e-6, gttol=1e-6)
    solver_d_tao.getKSP().setType("preonly")
    solver_d_tao.getKSP().setTolerances(rtol=1.0e-6)
    solver_d_tao.getKSP().getPC().setType("lu")

    # We set the bound (Note: they are passed as reference and not as values)
    solver_d_tao.setVariableBounds(dlb.x.petsc_vec, dub.x.petsc_vec)

    Nincr = len(load_steps) - 1
    ffile = XDMFFile(MPI.COMM_WORLD, "results.xdmf", "w")
    ffile.write_mesh(mesh)

    # Pyvista plotting grid
    if PYVISTA_ON:
        grid = create_grid(mesh)

    vol = assemble_scalar(form(Constant(mesh, 1.0) * dx))
    results = np.zeros((Nincr + 1, 4))
    t = 0
    for i, t in enumerate(load_steps[1:]):
        Uimp.value = t
        print("Increment {:3d}".format(i + 1))
        niter = 0
        for niter in range(Nitermax):
            # Solve displacement
            problem_u.solve()
            # Compute new damage
            solver_d_tao.solve(d.x.petsc_vec)

            # check error and update
            L2_error = form(inner(d - dold, d - dold) * dx)
            error_L2 = np.sqrt(assemble_scalar(L2_error)) / vol

            # Update damage
            d.x.petsc_vec.copy(dold.x.petsc_vec)

            print("    Iteration {:3d}: ||Res||_2={:5e}".format(niter, error_L2))
            if error_L2 < tol:
                break
        else:
            warnings.warn("Too many iterations in fixed point algorithm")

        # Update lower bound to account for irreversibility
        d.x.petsc_vec.copy(dlb.x.petsc_vec)

        # compute apparent stress and max damage
        if problem == "shear":
            L = assemble_scalar(form(Constant(mesh, 1.0) * ds(4)))
            Sig_app = assemble_scalar(form(sigma(u, d)[0, 1] * ds(4))) / L
        else:
            W = assemble_scalar(form(Constant(mesh, 1.0) * ds(2)))
            Sig_app = assemble_scalar(form(sigma(u, d)[0, 0] * ds(2))) / W

        en_el = assemble_scalar(form(elastic_energy)) / Gc.value
        en_f = assemble_scalar(form(fracture_energy)) / Gc.value

        results[i + 1, :] = (t, Sig_app, en_el, en_f)

        # compute stress
        stress_expr = Expression(sigma(u, d), V_sig.element.interpolation_points())
        sig.interpolate(stress_expr)

        # Create plotter
        if PYVISTA_ON and (
            (plot_every > 0 and i % plot_every == 0)
            or (plot_every == 0 and i == Nincr - 1)
        ):
            plot_damage(grid, d)

        # Export to Paraview
        if export_results:
            ffile.write_function(d, t)
            ffile.write_function(u, t)
            ffile.write_function(sig, t)

        ffile.close()
    return results, u, d, sig
