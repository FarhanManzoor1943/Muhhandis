import matplotlib.pyplot as plt
import numpy as np
import dolfinx


def init_pyvista():
    import pyvista

    pyvista.OFF_SCREEN = False
    pyvista.set_jupyter_backend("static")


FIGSIZE = (600, 600)


def plot_results(
    problem, results, E, Gc, l, model, d, u, sig, mesh, PYVISTA_ON, export_results=True
):
    print("Dissipated energy/Gc:", results[-1, 3])
    sigmax = max(results[:, 1])
    epsmax = results[np.where(results[:, 1] == sigmax)[0][0], 0]
    print("Maximum stress:      ", sigmax)
    print("Strain at max stress:", epsmax)

    if problem != "shear":
        points = np.zeros((1000, 3))
        points[:, 0] = np.linspace(0, 1, 1000)
        points[:, 1] = max(mesh.geometry.x[:, 1]) / 2

        plt.figure()
        points, values = evaluate_on_points(d, points)
        plt.plot(points[:, 0], values, "-", label="damage profile")
        plt.xlabel("x")
        plt.ylabel("Damage")
        plt.ylim(0, 1.0)
        plt.title("Damage profile along $y=W/2$")
        if export_results:
            plt.savefig("damage_profile.pdf")

    plt.figure()
    plt.plot(results[:, 0], results[:, 1], "-x", label="FE solution")
    plt.plot([epsmax, epsmax, 0], [0, sigmax, sigmax], "--k", linewidth=1)
    exx = results[:, 0]
    dam = 0 * exx
    s = E * exx
    if model == "AT1":
        cw = 8 / 3.0
        exx0 = (float(Gc) / float(l) / cw / float(E)) ** 0.5
        exxd = exx[exx >= exx0]
        dam[exx >= exx0] = 1 - (exx0 / exxd) ** 2
        s[exx >= exx0] = (1 - dam[exx >= exx0]) ** 2 * E * exxd
    elif model == "AT2":
        cw = 2.0
        exx0 = (float(Gc) / float(l) / cw / float(E)) ** 0.5
        dam[1:] = 1 / (1 + 2 * exx0**2 / exx[1:] ** 2)
        s = (1 - dam) ** 2 * E * exx
    if problem == "homog":
        plt.plot(exx, s, "--", label="Homogeneous solution")
    plt.xlabel("Uniaxial strain $\epsilon_{xx}$")
    plt.ylabel("Apparent stress $F/S$ (MPa)")
    plt.legend()
    if export_results:
        plt.savefig("stress_strain_curve.pdf")
    plt.show()

    plt.figure()
    plt.plot(results[:, 0], results[:, 3], "-x", label="fracture (FE solution)")
    plt.plot(results[:, 0], results[:, 2], "-x", label="elastic (FE solution)")
    plt.plot(
        results[:, 0], results[:, 2] + results[:, 3], "-x", label="total (FE solution)"
    )
    #    if problem == "homog":
    #        plt.plot(exx, dam, '--', label="Homogeneous solution")
    plt.xlabel("Uniaxial strain $\epsilon_{xx}$")
    plt.ylabel("Energies/Gc")
    plt.legend()
    if export_results:
        plt.savefig("fracture_energy_evol_curve.pdf")
    plt.show()


def create_grid(mesh):
    import pyvista

    V = dolfinx.fem.functionspace(mesh, ("CG", 1))
    # Create pyvista grid
    topology, cell_types, geometry = dolfinx.plot.vtk_mesh(V)
    return pyvista.UnstructuredGrid(topology, cell_types, geometry)


def plot_mesh(mesh):
    import pyvista

    # Create plotter
    plotter = pyvista.Plotter(window_size=FIGSIZE)
    # we first add the grid
    grid = create_grid(mesh)
    plotter.add_mesh(grid, show_edges=True, style="wireframe", color="k")
    # Then we display the scene
    plotter.view_xy()
    plotter.set_background("lightgray")
    plotter.show()


def plot_damage(grid, d):
    import pyvista

    plotter = pyvista.Plotter()
    grid.point_data["d"] = d.x.array
    grid.set_active_scalars("d")
    plotter.add_mesh(
        grid, show_edges=False, show_scalar_bar=True, clim=[0, 1], cmap="bone_r"
    )
    plotter.add_mesh(grid, show_edges=True, opacity=0.25, style="wireframe", color="k")
    plotter.view_xy()
    plotter.set_background("lightgray")
    plotter.show()


def evaluate_on_points(field, points):
    """This function returns the values of a field on a set of points

    Parameters
    ==========
    field: The FEniCS function from which we wan
    points: a n x 3 np.array with the coordinates of the points where to evaluate
    the function

    It returns:
    - points_on_proc: the local slice of the point array
    - values_on_proc: the local slice of the values
    """

    import dolfinx.geometry
    import numpy as np

    mesh = field.function_space.mesh
    bb_tree = dolfinx.geometry.bb_tree(mesh, mesh.topology.dim)
    # for each point, compute a colliding cells and append to the lists
    points_on_proc = []
    cells = []
    cell_candidates = dolfinx.geometry.compute_collisions_points(
        bb_tree, points
    )  # get candidates
    colliding_cells = dolfinx.geometry.compute_colliding_cells(
        mesh, cell_candidates, points
    )  # get actual
    for i, point in enumerate(points):
        if len(colliding_cells.links(i)) > 0:
            cc = colliding_cells.links(i)[0]
            points_on_proc.append(point)
            cells.append(cc)
    # convert to numpy array
    points_on_proc = np.array(points_on_proc)
    cells = np.array(cells)
    values_on_proc = field.eval(points_on_proc, cells)

    return points_on_proc, values_on_proc
